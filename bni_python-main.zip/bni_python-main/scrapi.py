# -*- coding: utf-8 -*-
"""
Created on Thu Feb  9 14:50:34 2023

@author: Gautam-Infisms
"""
import csv
#This will not run on online IDE
import requests
from bs4 import BeautifulSoup

with open("data.html") as fp:
    soup = BeautifulSoup(fp, "html.parser")


    
soup = soup.body.table.tbody
#print(soup.find_all("tr"))
chap_name = "BNI-Naira"
city_name = "Coimbatore"
row_head =['GroupName','Name', 'Company', 'Profession/Specialty', 'Phone','City']
Data = []
for t in soup.find_all("tr"):
    raw = t.find_all("td")
    #n = raw[3].text
    Data.append(chap_name)
    Data.append(raw[0].text)
    Data.append(raw[1].text)
    Data.append(raw[2].text)
    Data.append(raw[3].text)
    Data.append(city_name)
    #print(n)
    
rows = [Data[i:i + 6] for i in range(0, len(Data), 6)]
fname = 'BNI_'+city_name+'_'+chap_name[4:]+'.csv'
with open(fname, 'w', encoding='utf_8_sig', newline="") as csvfile:
    csvwriter = csv.writer(csvfile)
    csvwriter.writerow(row_head)
    csvwriter.writerows(rows)