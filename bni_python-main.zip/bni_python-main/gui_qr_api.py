import tkinter as tk
import requests
import time  
# Top level window
frame = tk.Tk()
frame.title("TextBox Input")
frame.geometry('1800x1200')
# Function for getting Input
# from textbox and printing it 
# at label widget
  
def send_msg():
    inp = inputtxt.get(1.0, "end-1c")
    num = inp.split('\n')
    print(num)
    url = "http://whapi.infisms.com/file.php"


    for i in range(0,len(num)):
        print(num[i])
        time.sleep(40)
        payload={'filename': 'BNI_MITUL_SHAH',
        'key': 'kbrpDFnnAhIukyYa',
        'number': num[i],
        'caption': '''Hii..
This is Mitul Shah,  owner of Infinity Solution from BNI RAPHAEL Chapter & my Catagory is Mass Communication...

We basically deal in Bulk SMS Service and WhatsApp Automation Services...the main feature of that is we are  all India Service Provider..

★*Our Service Ranges are:*

1) Bulk SMS service
2) OTP sms
3) Business WhatsApp Verification
4) WhatsApp Integration and Green tick services 
5) AI Base Chatbot 
6) Mass Email Service 
7) Promotion SMS and WhatsApp Services...

You can contact me on 9898439675
email: mitul@infisms.com'''}
        files=[
          ('data',('BNI_MITUL_SHAH.pdf',open('C:/Users/Gautam-Infisms/Downloads/BNI_MITUL_SHAH.pdf','rb'),'application/pdf'))
        ]
        headers = {}

        response = requests.request("POST", url, headers=headers, data=payload, files=files)

        print(response.text)
    frame.destroy()
  
# TextBox Creation
inputtxt = tk.Text(frame,
                   height = 35,
                   width = 40)
  
inputtxt.pack()
  
# Button Creation
printButton = tk.Button(frame,
                        text = "Send", 
                        command = send_msg)
printButton.pack()
  

frame.mainloop()
