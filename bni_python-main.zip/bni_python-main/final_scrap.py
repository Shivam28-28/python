# -*- coding: utf-8 -*-
"""
Created on Mon Feb 13 09:38:58 2023

@author: Gautam-Infisms
"""

from lxml import html
from bs4 import BeautifulSoup
from time import sleep
from selenium import webdriver
import csv


def parse(url):
    response = webdriver.Chrome()
    response.get(url)
    sleep(3)
    sourceCode = response.page_source
    return sourceCode


ul = "https://bni-yvelines.fr/excellence-plaisir/fr/listemembre"
soup = BeautifulSoup(parse(ul), 'lxml')
x = soup.find("table", id="chapterListTable")
# print(x.tbody)

tab = x.tbody
# print(tab)e
chap_name = "BNI_78-05 BNI Online Plaisir Excellence - 78 - Yvelines"
city_name = "Plaisir"
country = "France"
row_head = ['GroupName', 'Name', 'Company',
            'Profession/Specialty', 'Phone', 'City', 'Country']
Data = []
for t in tab.find_all("tr"):
    raw = t.find_all("td")
    #n = raw[3].text
    Data.append(chap_name)
    Data.append(raw[0].text)
    Data.append(raw[1].text)
    Data.append(raw[2].text)
    Data.append(raw[3].text)
    Data.append(city_name)
    Data.append(country)
    # print(n)

rows = [Data[i:i + 7] for i in range(0, len(Data), 7)]
fname = 'BNI_'+city_name+'_'+chap_name[4:]+'_FRA.csv'
with open(fname, 'w', encoding='utf_8_sig', newline="") as csvfile:
    csvwriter = csv.writer(csvfile)
    csvwriter.writerow(row_head)
    csvwriter.writerows(rows)
