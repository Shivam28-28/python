import tkinter as tk
import requests
import time  
# Top level window
frame = tk.Tk()
frame.title("TextBox Input")
frame.geometry('1800x1200')
# Function for getting Input
# from textbox and printing it 
# at label widget
  
def send_msg():
    inp = inputtxt.get(1.0, "end-1c")
    num = inp.split('\n')
    print(num)
    url = "https://api.whatsdesk.in/v1/text.php"


    for i in range(0,len(num)):
        print(num[i])
        time.sleep(25)
        payload = {'message': '''Hii..
This is *Mitul Shah*,  owner of Infinity Solution from BNI RAPHAEL Chapter.
We *infinity solution* providing quality mass communication and marketing solutions like... 

1️⃣what\'s app business API with buttons and sending from own numbers
2️⃣Send specific invitation card and certificates with own what\'s app number
3️⃣AI based chatbot solution for channel like What\'s app, FB messenger, Telegram and websites
4️⃣Mass email marketing
5️⃣All type of SMS services
6️⃣What\'s app marketing services

For more details call or do 1-2-1 online meeting with us.

Mitul Shah
📱: 9898439675
✉️ : mitul@infisms.com''',
'key': 'kbrpDFnnAhIukyYa',
'number': num[i]}
        files=[

        ]
        headers = {}

        response = requests.request("POST", url, headers=headers, data=payload, files=files)

        print(response.text)
    frame.destroy()
  
# TextBox Creation
inputtxt = tk.Text(frame,
                   height = 35,
                   width = 40)
  
inputtxt.pack()
  
# Button Creation
printButton = tk.Button(frame,
                        text = "Send", 
                        command = send_msg)
printButton.pack()
  

frame.mainloop()
