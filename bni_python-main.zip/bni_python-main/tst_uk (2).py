from lxml import html
from bs4 import BeautifulSoup
from time import sleep
from selenium import webdriver
import csv


def parse(url):
    response = webdriver.Chrome()
    response.get(url)
    sleep(3)
    sourceCode = response.page_source
    return sourceCode


ul = "https://bni.co.uk/en-GB/memberlist?countryIds=8150&regionId=&chapterName=&chapterArea=2491&memberKeywords=&chapterCity=&memberFirstName=&memberLastName=&memberCompany="
soup = BeautifulSoup(parse(ul), 'lxml')
x = soup.find("table", id="memberListTable")
#print(x.tbody)

tab = x.tbody
#print(tab)

chap_name = "BNI_testUK"
city_name = ""
country = "UK"
row_head = ['GroupName', 'Name', 'Company',
            'Profession/Specialty', 'Phone', 'City', 'Country']
Data = []

for t in tab.find_all("tr"):
    raw = t.find_all("td")
    if raw[0].a is not None:
        #print(raw[2].text)
        Data.append(chap_name)
        Data.append(raw[0].text)
        Data.append(raw[5].text)
        Data.append(raw[4].text)
        soup2 = BeautifulSoup(parse('https://bni.co.uk/en-GB/'+raw[0].a['href']), 'lxml')
        tn= soup2.find_all("div", {"class": "memberContactDetails"})
        Data.append(tn[0].a.text)
        Data.append(raw[2].text)
        Data.append(country)
    


rows = [Data[i:i + 7] for i in range(0, len(Data), 7)]
fname = 'BNI_'+city_name+'_'+chap_name[4:]+'_SNI.csv'
with open(fname, 'w', encoding='utf_8_sig', newline="") as csvfile:
    csvwriter = csv.writer(csvfile)
    csvwriter.writerow(row_head)
    csvwriter.writerows(rows)
print("CSV created")
