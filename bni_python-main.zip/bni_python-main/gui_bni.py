# import openpyxl and tkinter modules

from tkinter import *
from lxml import html
from bs4 import BeautifulSoup
from time import sleep
from selenium import webdriver
import csv

def parse(url):
    response = webdriver.Chrome()
    response.get(url)
    sleep(3)
    sourceCode = response.page_source
    return sourceCode

def dataex(nameurl,chap,city,country,second_url):
        ul = nameurl
        soup = BeautifulSoup(parse(ul), 'lxml')
        x = soup.find("table", id="chapterListTable")
        #print(x.tbody)

        tab = x.tbody
        #print(tab)

        chap_name = "BNI_"+chap
        city_name = city
        
        row_head = ['GroupName', 'Name', 'Company','Profession/Specialty','Personal Details','Website','Business Details','Tag', 'Phone', 'City', 'Country']
        Data = []

        for t in tab.find_all("tr"):
            raw = t.find_all("td")
            #print(raw)
            #print(raw[0].a['href'])
            if raw[0].a is not None:
                #print(raw[2].text)
                Data.append(chap_name)
                Data.append(raw[0].text)
                Data.append(raw[1].text)
                Data.append(raw[2].text)
                soup2 = BeautifulSoup(parse(second_url+raw[0].a['href']), 'lxml')

                #tn= soup2.find_all("div", {"class": "memberContactDetails"})
                cd = soup2.find_all("div", {"class": "textHolder"})
                for c in cd:
                    #print(c.find_all('h6')[0].get_text())
                    ppd = c.find_all('h6')[0].get_text().strip()
                    #print(ppd)
                    Data.append(ppd)
                    if(c.find_all('a')) != []:
                        #print(c.find_all('a')[0].get_text())
                        webd = c.find_all('a')[0].get_text().strip()
                        #print(webd)
                        Data.append(webd)
                    else:
                        Data.append("Not avalible")
                    #print('-------')
                bissec = soup2.find_all("section", {"class": "widgetMemberTxtVideo"})
        ##        print(bissec)
        ##        
                for re in bissec:
                    st_bde = ''
                    mem = re.find_all("p")
                    for i in range(0,len(mem)):
                                   st_bde = st_bde + mem[i].get_text()
                    #print(st_bde)
                    Data.append(st_bde)               
                    #print("-------end------")
                fudet = soup2.find_all("div", {"class": "rowTwoCol"})
                for fd in fudet:
                    od = ''
                    fdlist = fd.find_all("p")
                    for i in range(0,len(fdlist)):
                        od = od + fdlist[i].get_text()
                    #print(od)
                    Data.append(od) 
                    #print("----end----")
                
                Data.append(raw[3].text)
                Data.append(city_name)
                Data.append(country)
            


        rows = [Data[i:i + 11] for i in range(0, len(Data), 11)]
        fname = 'BNI_'+city_name+'_'+chap_name[4:]+'_'+country+'.csv'
        with open(fname, 'w', encoding='utf_8_sig', newline="") as csvfile:
            csvwriter = csv.writer(csvfile)
            csvwriter.writerow(row_head)
            csvwriter.writerows(rows)
        print("CSV created")
        sucess.config(text= "CSV Created")
        



# Function to set focus (cursor)
def focus1(event):
	# set focus on the course_field box
	course_field.focus_set()


# Function to set focus
def focus2(event):
	# set focus on the sem_field box
	sem_field.focus_set()


# Function to set focus
def focus3(event):
	# set focus on the form_no_field box
	form_no_field.focus_set()


# Function to set focus
def focus4(event):
	# set focus on the contact_no_field box
	contact_no_field.focus_set()





# Function for clearing the
# contents of text entry boxes
def clear():
	
	# clear the content of text entry box
	name_field.delete(0, END)
	course_field.delete(0, END)
	sem_field.delete(0, END)
	form_no_field.delete(0, END)
	contact_no_field.delete(0, END)
	sucess.config(text= "")


# Function to take data from GUI
# window and write to an excel file
def insert():
	
	# if user not fill any entry
	# then print "empty input"
	if (name_field.get() == "" and
		course_field.get() == "" and
		sem_field.get() == "" and
		form_no_field.get() == "" and
		contact_no_field.get() == ""):
			
		print("empty input")

	else:

		

		# get method returns current text
		# as string which we write into
		# excel spreadsheet at particular location
		nameurl = name_field.get()
		chap = course_field.get()
		city = sem_field.get()
		country = form_no_field.get()
		second_url = contact_no_field.get()
		dataex(nameurl,chap,city,country,second_url)
		
		
		# call the clear() function
		clear()


# Driver code
if __name__ == "__main__":
	
	# create a GUI window
	root = Tk()

	# set the background colour of GUI window
	root.configure(background='light green')

	# set the title of GUI window
	root.title("Infinity Solution")

	# set the configuration of GUI window
	root.geometry("500x300")



	# create a Form label
	heading = Label(root, text="BNI DATA Scraper", bg="light green")

	# create a Name label
	name = Label(root, text="Primary URL", bg="light green")

	# create a Course label
	course = Label(root, text="Chapter Name", bg="light green")

	# create a Semester label
	sem = Label(root, text="City Name", bg="light green")

	# create a Form No. label
	form_no = Label(root, text="Country Name", bg="light green")

	# create a Contact No. label
	contact_no = Label(root, text="Secondaty URL", bg="light green")

	sucess = Label(root, text="", bg="light green")
	# grid method is used for placing
	# the widgets at respective positions
	# in table like structure .
	heading.grid(row=0, column=1)
	name.grid(row=1, column=0)
	course.grid(row=2, column=0)
	sem.grid(row=3, column=0)
	form_no.grid(row=4, column=0)
	contact_no.grid(row=5, column=0)
	
	sucess.grid(row=9,column=0)
	# create a text entry box
	# for typing the information
	name_field = Entry(root)
	course_field = Entry(root)
	sem_field = Entry(root)
	form_no_field = Entry(root)
	contact_no_field = Entry(root)
	
	

	# bind method of widget is used for
	# the binding the function with the events

	# whenever the enter key is pressed
	# then call the focus1 function
	name_field.bind("<Return>", focus1)

	# whenever the enter key is pressed
	# then call the focus2 function
	course_field.bind("<Return>", focus2)

	# whenever the enter key is pressed
	# then call the focus3 function
	sem_field.bind("<Return>", focus3)

	# whenever the enter key is pressed
	# then call the focus4 function
	form_no_field.bind("<Return>", focus4)

	

	# grid method is used for placing
	# the widgets at respective positions
	# in table like structure .
	name_field.grid(row=1, column=1, ipadx="100")
	course_field.grid(row=2, column=1, ipadx="100")
	sem_field.grid(row=3, column=1, ipadx="100")
	form_no_field.grid(row=4, column=1, ipadx="100")
	contact_no_field.grid(row=5, column=1, ipadx="100")
	



	# create a Submit Button and place into the root window
	submit = Button(root, text="Submit", fg="Black",
							bg="Red", command=insert)
	submit.grid(row=8, column=1)

	# start the GUI
	root.mainloop()
