from lxml import html
from bs4 import BeautifulSoup
from time import sleep
from selenium import webdriver
import csv


def parse(url):
    response = webdriver.Chrome()
    response.get(url)
    sleep(3)
    sourceCode = response.page_source
    return sourceCode


ul = "https://bni-bangalore.in/bangalore-south-east-amazzing/en-IN/memberlist"
soup = BeautifulSoup(parse(ul), 'lxml')
x = soup.find("table", id="chapterListTable")
#print(x.tbody)

tab = x.tbody
#print(tab)

chap_name = "BNI_Amazzingbhargav"
city_name = "Bangalore-south-east"
country = "India"
row_head = ['GroupName', 'Name', 'Company',
            'Profession/Specialty','Personal Details','Website','Business Details','Tag', 'Phone', 'City', 'Country']
Data = []

for t in tab.find_all("tr"):
    raw = t.find_all("td")
    #print(raw)
    #print(raw[0].a['href'])
    if raw[0].a is not None:
        #print(raw[2].text)
        Data.append(chap_name)
        Data.append(raw[0].text)
        Data.append(raw[1].text)
        Data.append(raw[2].text)
        soup2 = BeautifulSoup(parse('https://bni-bangalore.in/bangalore-south-east-amazzing/en-IN/'+raw[0].a['href']), 'lxml')

        #tn= soup2.find_all("div", {"class": "memberContactDetails"})
        cd = soup2.find_all("div", {"class": "textHolder"})
        for c in cd:
            #print(c.find_all('h6')[0].get_text())
            ppd = c.find_all('h6')[0].get_text().strip()
            #print(ppd)
            Data.append(ppd)
            if(c.find_all('a')) != []:
                #print(c.find_all('a')[0].get_text())
                webd = c.find_all('a')[0].get_text().strip()
                #print(webd)
                Data.append(webd)
            else:
                Data.append("Not avalible")
            #print('-------')
        bissec = soup2.find_all("section", {"class": "widgetMemberTxtVideo"})
##        print(bissec)
##        
        for re in bissec:
            st_bde = ''
            mem = re.find_all("p")
            for i in range(0,len(mem)):
                           st_bde = st_bde + mem[i].get_text()
            #print(st_bde)
            Data.append(st_bde)               
            #print("-------end------")
        fudet = soup2.find_all("div", {"class": "rowTwoCol"})
        for fd in fudet:
            od = ''
            fdlist = fd.find_all("p")
            for i in range(0,len(fdlist)):
                od = od + fdlist[i].get_text()
            #print(od)
            Data.append(od) 
            #print("----end----")
        
        Data.append(raw[3].text)
        Data.append(city_name)
        Data.append(country)
    


rows = [Data[i:i + 11] for i in range(0, len(Data), 11)]
fname = 'BNI_'+city_name+'_'+chap_name[4:]+'_IND.csv'
with open(fname, 'w', encoding='utf_8_sig', newline="") as csvfile:
    csvwriter = csv.writer(csvfile)
    csvwriter.writerow(row_head)
    csvwriter.writerows(rows)
print("CSV created")
